import { ethers } from "ethers";
import { TOKEN_ADDRESS, ERC20_ABI } from "./config";

export class TokenClient {
  constructor() {
    this.provider = null;
    this.signer = null;
    this.account = null;
    this.contract = null;
    this.decimals = 18;
    this._isListening = false;
  }

  async connect() {
    if (!window.ethereum) throw new Error("MetaMask not found");

    this.provider = new ethers.BrowserProvider(window.ethereum);
    await this.provider.send("eth_requestAccounts", []);
    this.signer = await this.provider.getSigner();
    this.account = await this.signer.getAddress();

    this.contract = new ethers.Contract(TOKEN_ADDRESS, ERC20_ABI, this.signer);
    this.decimals = await this.contract.decimals();

    return this.account;
  }

  async getBalance(addr = this.account) {
    if (!ethers.isAddress(addr)) {
      throw new Error("Invalid address for balance check");
    }
    const raw = await this.contract.balanceOf(addr);
    return ethers.formatUnits(raw, this.decimals);
  }

  parseAmount(amountStr) {
    return ethers.parseUnits(amountStr || "0", this.decimals);
  }

  validateTransferParams(to, amountStr) {
    if (!ethers.isAddress(to)) {
      throw new Error("Invalid recipient address. Please enter a valid 0x address.");
    }

    const amount = this.parseAmount(amountStr);
    if (amount <= 0n) {
      throw new Error("Amount must be greater than 0");
    }

    return amount;
  }

  /**
   * Оценка газа для транзакции пользователя
   * Возвращает { success: boolean, gas: string, error?: string }
   */
  async estimateGas(to, amountStr) {
    // Валидация
    if (!ethers.isAddress(to)) {
      return { success: false, gas: null, error: "Invalid address" };
    }

    const amount = this.parseAmount(amountStr);
    if (amount <= 0n) {
      return { success: false, gas: null, error: "Amount must be > 0" };
    }

    // Проверяем баланс
    const balance = await this.contract.balanceOf(this.account);
    if (amount > balance) {
      return { success: false, gas: null, error: "Insufficient balance" };
    }

    try {
      const gas = await this.contract.transfer.estimateGas(to, amount);
      return { success: true, gas: gas.toString(), error: null };
    } catch (e) {
      return { success: false, gas: null, error: e?.shortMessage || "Transaction will revert" };
    }
  }

  async transfer(to, amountStr) {
    const amount = this.validateTransferParams(to, amountStr);
    const tx = await this.contract.transfer(to, amount);
    return await tx.wait();
  }

  onTransfer(cb) {
    if (this._isListening) {
      console.log("Already listening to Transfer events, skipping...");
      return;
    }

    this.contract.removeAllListeners("Transfer");
    this.contract.on("Transfer", (from, to, value) => cb({ from, to, value }));
    this._isListening = true;
    console.log("Subscribed to Transfer events");
  }

  offTransfer() {
    this.contract.removeAllListeners("Transfer");
    this._isListening = false;
    console.log("Unsubscribed from Transfer events");
  }
}
