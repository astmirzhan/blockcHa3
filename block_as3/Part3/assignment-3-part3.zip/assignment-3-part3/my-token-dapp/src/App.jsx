import { useState, useEffect, useRef, useCallback } from "react";
import { TokenClient } from "./TokenClient";
import { ethers } from "ethers";
import "./App.css";

// Singleton клиент
const client = new TokenClient();

// Toast уведомления компонент
function Toast({ toast, onClose }) {
  useEffect(() => {
    if (toast.autoClose !== false) {
      const timer = setTimeout(() => onClose(toast.id), 4000);
      return () => clearTimeout(timer);
    }
  }, [toast, onClose]);

  const icons = {
    success: "✅",
    error: "❌",
    warning: "⚠️",
    info: "ℹ️",
    loading: "⏳"
  };

  return (
    <div className={`status-toast ${toast.type}`}>
      <span className="status-icon">{icons[toast.type]}</span>
      <div className="status-content">
        <div className="status-title">{toast.title}</div>
        {toast.message && <div className="status-message">{toast.message}</div>}
      </div>
      <button className="status-close" onClick={() => onClose(toast.id)}>×</button>
    </div>
  );
}

export default function App() {
  // State
  const [account, setAccount] = useState(null);
  const [balance, setBalance] = useState("-");
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");
  const [gasResult, setGasResult] = useState(null); // { success, gas, error }
  const [events, setEvents] = useState([]);
  const [toasts, setToasts] = useState([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isEstimating, setIsEstimating] = useState(false);
  const [isTransferring, setIsTransferring] = useState(false);

  // Refs
  const isSubscribedRef = useRef(false);
  const toastIdRef = useRef(0);

  // Toast helpers
  const addToast = useCallback((type, title, message = "", autoClose = true) => {
    const id = ++toastIdRef.current;
    setToasts(prev => [...prev, { id, type, title, message, autoClose }]);
    return id;
  }, []);

  const removeToast = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const updateToast = useCallback((id, type, title, message = "") => {
    setToasts(prev => prev.map(t =>
      t.id === id ? { ...t, type, title, message, autoClose: true } : t
    ));
  }, []);

  // Cleanup
  useEffect(() => {
    return () => {
      if (client.contract) {
        client.offTransfer();
        isSubscribedRef.current = false;
      }
    };
  }, []);

  // Balance refresh
  const refreshBalance = async () => {
    try {
      const b = await client.getBalance();
      setBalance(b);
    } catch (e) {
      console.error("Balance refresh error:", e);
    }
  };

  // Error handler
  const handleTxError = (e, context = "") => {
    console.error(`${context} error:`, e);

    // User rejected
    if (
      e?.code === "ACTION_REJECTED" ||
      e?.code === 4001 ||
      e?.info?.error?.code === 4001 ||
      e?.message?.toLowerCase().includes("user rejected")
    ) {
      addToast("warning", "Transaction Rejected", "You cancelled the transaction");
      return;
    }

    // Insufficient balance
    if (e?.message?.includes("insufficient") || e?.message?.includes("exceeds balance")) {
      addToast("error", "Insufficient Balance", "You don't have enough tokens");
      return;
    }

    // Invalid address
    if (e?.message?.includes("Invalid") && e?.message?.includes("address")) {
      addToast("error", "Invalid Address", e.message);
      return;
    }

    // Generic error
    const msg = e?.shortMessage || e?.reason || e?.message || String(e);
    addToast("error", `${context} Error`, msg);
  };

  // Connect wallet
  const connect = async () => {
    if (isConnecting) return;

    setIsConnecting(true);
    const toastId = addToast("info", "Connecting...", "Please confirm in MetaMask", false);

    try {
      const acc = await client.connect();
      setAccount(acc);
      await refreshBalance();
      updateToast(toastId, "success", "Connected!", `${acc.slice(0, 6)}...${acc.slice(-4)}`);

      // Subscribe to events once
      if (!isSubscribedRef.current) {
        client.onTransfer(async ({ from, to: toAddr, value }) => {
          const v = ethers.formatUnits(value, client.decimals);
          const shortFrom = `${from.slice(0, 6)}...${from.slice(-4)}`;
          const shortTo = `${toAddr.slice(0, 6)}...${toAddr.slice(-4)}`;

          setEvents(prev => [{
            id: Date.now(),
            from: shortFrom,
            to: shortTo,
            amount: parseFloat(v).toLocaleString()
          }, ...prev.slice(0, 49)]);

          // Refresh if we're involved
          if (
            from.toLowerCase() === client.account?.toLowerCase() ||
            toAddr.toLowerCase() === client.account?.toLowerCase()
          ) {
            await refreshBalance();
          }
        });
        isSubscribedRef.current = true;
      }
    } catch (e) {
      removeToast(toastId);
      handleTxError(e, "Connect");
    } finally {
      setIsConnecting(false);
    }
  };

  // Estimate gas
  const estimate = async () => {
    const recipientAddr = to.trim();
    const amountStr = amount.trim();

    // Validation
    if (!ethers.isAddress(recipientAddr)) {
      addToast("error", "Invalid Address", "Please enter a valid 0x... address");
      return;
    }

    if (!amountStr || parseFloat(amountStr) <= 0) {
      addToast("error", "Invalid Amount", "Amount must be greater than 0");
      return;
    }

    setIsEstimating(true);
    setGasResult(null);

    try {
      const result = await client.estimateGas(recipientAddr, amountStr);
      setGasResult(result);

      if (result.success) {
        addToast("success", "Transaction Will Succeed ✅", `Estimated gas: ${result.gas}`);
      } else {
        addToast("error", "Transaction Will Fail ❌", result.error);
      }
    } catch (e) {
      handleTxError(e, "Estimate");
    } finally {
      setIsEstimating(false);
    }
  };

  // Transfer
  const doTransfer = async () => {
    const recipientAddr = to.trim();
    const amountStr = amount.trim();

    // Validation
    if (!ethers.isAddress(recipientAddr)) {
      addToast("error", "Invalid Address", "Please enter a valid 0x... address");
      return;
    }

    if (!amountStr || parseFloat(amountStr) <= 0) {
      addToast("error", "Invalid Amount", "Amount must be greater than 0");
      return;
    }

    setIsTransferring(true);
    const toastId = addToast("info", "Sending Transaction...", "Please confirm in MetaMask", false);

    try {
      const receipt = await client.transfer(recipientAddr, amountStr);
      updateToast(
        toastId,
        "success",
        "Transfer Complete! 🎉",
        `Block #${receipt.blockNumber}`
      );
      await refreshBalance();

      // Clear inputs
      setTo("");
      setAmount("");
      setGasResult(null);
    } catch (e) {
      removeToast(toastId);
      handleTxError(e, "Transfer");
    } finally {
      setIsTransferring(false);
    }
  };

  // Short address helper
  const shortAddress = (addr) => addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : "-";

  return (
    <div className="app-container">
      {/* Toast Container */}
      <div className="status-container">
        {toasts.map(toast => (
          <Toast key={toast.id} toast={toast} onClose={removeToast} />
        ))}
      </div>

      {/* Header */}
      <header className="app-header">
        <div className="app-logo">🪙</div>
        <h1 className="app-title">Token dApp</h1>
        <p className="app-subtitle">ERC-20 Token Transfer Interface</p>
      </header>

      {/* Connect Card */}
      <div className="card">
        <div className="card-header">
          <span className="card-icon">👛</span>
          <span className="card-title">Wallet Connection</span>
          {account && (
            <span className="connection-badge">
              <span className="dot"></span>
              Connected
            </span>
          )}
        </div>

        {!account ? (
          <button className="btn btn-primary btn-full" onClick={connect} disabled={isConnecting}>
            {isConnecting ? (
              <>
                <span className="spinner"></span>
                Connecting...
              </>
            ) : (
              <>🦊 Connect MetaMask</>
            )}
          </button>
        ) : (
          <div className="info-block">
            <div className="info-row">
              <span className="info-label">📍 Address</span>
              <span className="info-value address">{shortAddress(account)}</span>
            </div>
            <div className="info-row">
              <span className="info-label">💰 Balance</span>
              <span className="info-value balance">{balance} ONT</span>
            </div>
          </div>
        )}
      </div>

      {/* Transfer Card */}
      {account && (
        <div className="card">
          <div className="card-header">
            <span className="card-icon">📤</span>
            <span className="card-title">Transfer Tokens</span>
          </div>

          <div className="input-group">
            <label className="input-label">Recipient Address</label>
            <input
              className="input"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="0x..."
              disabled={isTransferring}
            />
          </div>

          <div className="input-group" style={{ marginTop: "1rem" }}>
            <label className="input-label">Amount</label>
            <input
              className="input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              type="number"
              step="0.01"
              min="0"
              disabled={isTransferring}
            />
          </div>

          <div className="btn-row">
            <button
              className="btn btn-secondary"
              onClick={estimate}
              disabled={isEstimating || isTransferring || !to || !amount}
            >
              {isEstimating ? (
                <>
                  <span className="spinner"></span>
                  Estimating...
                </>
              ) : (
                <>⛽ Estimate Gas</>
              )}
            </button>
            <button
              className="btn btn-primary"
              onClick={doTransfer}
              disabled={isTransferring || !to || !amount}
            >
              {isTransferring ? (
                <>
                  <span className="spinner"></span>
                  Sending...
                </>
              ) : (
                <>🚀 Send Tokens</>
              )}
            </button>
          </div>

          {/* Gas Estimate Result */}
          {gasResult && (
            <div className={`gas-result ${gasResult.success ? 'success' : 'error'}`}>
              <div className="gas-result-icon">
                {gasResult.success ? '✅' : '❌'}
              </div>
              <div className="gas-result-content">
                <div className="gas-result-title">
                  {gasResult.success ? 'Transaction Will Succeed' : 'Transaction Will Fail'}
                </div>
                <div className="gas-result-detail">
                  {gasResult.success
                    ? `Estimated gas: ${gasResult.gas}`
                    : gasResult.error}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Events Card */}
      {account && (
        <div className="card">
          <div className="card-header">
            <span className="card-icon">📡</span>
            <span className="card-title">Live Transfer Events</span>
          </div>

          <div className="events-container">
            {events.length === 0 ? (
              <div className="events-empty">
                <div className="events-empty-icon">📭</div>
                <div>No events yet</div>
                <div style={{ fontSize: "0.75rem", marginTop: "0.25rem" }}>
                  Transfers will appear here in real-time
                </div>
              </div>
            ) : (
              events.map((event) => (
                <div key={event.id} className="event-item">
                  <span className="event-icon">🔄</span>
                  <div className="event-content">
                    <span className="event-addresses">
                      {event.from} <span className="event-arrow">→</span> {event.to}
                    </span>
                  </div>
                  <span className="event-amount">{event.amount}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
