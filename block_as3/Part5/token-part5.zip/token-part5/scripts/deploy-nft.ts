import { ethers } from "hardhat";

async function main() {
    console.log("🚀 Deploying MyNFT (ERC-721)...\n");

    const [deployer] = await ethers.getSigners();
    console.log("📍 Deployer address:", deployer.address);
    console.log("💰 Deployer balance:", ethers.formatEther(await ethers.provider.getBalance(deployer.address)), "ETH\n");

    // NFT parameters
    const nftName = "My NFT Collection";
    const nftSymbol = "MNFT";
    const baseURI = "https://api.example.com/metadata/";
    const maxSupply = 10000;
    const mintPrice = ethers.parseEther("0.01"); // 0.01 ETH

    console.log("📝 NFT Parameters:");
    console.log("   Name:", nftName);
    console.log("   Symbol:", nftSymbol);
    console.log("   Base URI:", baseURI);
    console.log("   Max Supply:", maxSupply.toLocaleString());
    console.log("   Mint Price:", ethers.formatEther(mintPrice), "ETH\n");

    // Deploy contract
    const MyNFT = await ethers.getContractFactory("MyNFT");
    const myNFT = await MyNFT.deploy(
        nftName,
        nftSymbol,
        baseURI,
        maxSupply,
        mintPrice
    );

    await myNFT.waitForDeployment();
    const nftAddress = await myNFT.getAddress();

    console.log("✅ MyNFT deployed successfully!");
    console.log("📍 Contract address:", nftAddress);

    // Verify deployment
    console.log("\n🔍 Verifying deployment...");
    console.log("   Name:", await myNFT.name());
    console.log("   Symbol:", await myNFT.symbol());
    console.log("   Max Supply:", (await myNFT.maxSupply()).toString());
    console.log("   Mint Price:", ethers.formatEther(await myNFT.mintPrice()), "ETH");
    console.log("   Minting Enabled:", await myNFT.mintingEnabled());
    console.log("   Owner:", await myNFT.owner());

    console.log("\n📋 Deployment Summary:");
    console.log("================================");
    console.log(`Contract: ${nftAddress}`);
    console.log(`Owner: ${deployer.address}`);
    console.log(`Network: ${(await ethers.provider.getNetwork()).name}`);
    console.log("================================\n");

    return myNFT;
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("❌ Deployment failed:", error);
        process.exit(1);
    });
