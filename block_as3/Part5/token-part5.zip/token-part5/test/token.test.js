const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Part 5 — Token tests", function () {
    async function deploy() {
        const [owner, alice, bob] = await ethers.getSigners();
        const Token = await ethers.getContractFactory("MyToken");
        const token = await Token.deploy("MyToken", "MTK", 18, 1000000);
        await token.waitForDeployment();
        return { token, owner, alice, bob };
    }

    it("Basic balance checks", async () => {
        const { token, owner, alice } = await deploy();
        expect(await token.balanceOf(owner.address)).to.be.gt(0n);
        expect(await token.balanceOf(alice.address)).to.equal(0n);
    });

    it("Transfer tests: updates balances", async () => {
        const { token, owner, alice } = await deploy();
        const amount = ethers.parseUnits("10", 18);


        const ob = await token.balanceOf(owner.address);
        const ab = await token.balanceOf(alice.address);

        await (await token.transfer(alice.address, amount)).wait();

        expect(await token.balanceOf(owner.address)).to.equal(ob - amount);
        expect(await token.balanceOf(alice.address)).to.equal(ab + amount);
    });

    it("Failing transfer: insufficient balance reverts", async () => {
        const { token, alice, bob } = await deploy();
        const amount = ethers.parseUnits("1", 18);
        await expect(token.connect(alice).transfer(bob.address, amount)).to.be.reverted;
    });

    it("Edge case: transfer to yourself", async () => {
        const { token, owner } = await deploy();
        const amount = ethers.parseUnits("5", 18);
        const before = await token.balanceOf(owner.address);
        await (await token.transfer(owner.address, amount)).wait();
        const after = await token.balanceOf(owner.address);
        expect(after).to.equal(before);
    });

    it("Gas estimation tests: success vs fail", async () => {
        const { token, alice } = await deploy();
        const ok = ethers.parseUnits("1", 18);
        const bad = ethers.parseUnits("999999999", 18);

        const gasOk = await token.transfer.estimateGas(alice.address, ok);
        expect(gasOk).to.be.gt(0n);

        await expect(token.transfer.estimateGas(alice.address, bad)).to.be.reverted;
    });

    it("Event emission tests: Transfer emitted", async () => {
        const { token, owner, alice } = await deploy();
        const amount = ethers.parseUnits("2", 18);

        await expect(token.transfer(alice.address, amount))
            .to.emit(token, "Transfer")
            .withArgs(owner.address, alice.address, amount);
    });

    it("Storage verification: final balances consistent", async () => {
        const { token, owner, bob } = await deploy();
        const amount = ethers.parseUnits("3", 18);

        const ob = await token.balanceOf(owner.address);
        const bb = await token.balanceOf(bob.address);

        await (await token.transfer(bob.address, amount)).wait();

        expect(await token.balanceOf(owner.address)).to.equal(ob - amount);
        expect(await token.balanceOf(bob.address)).to.equal(bb + amount);
    });

    it("Negative tests: bad params (0 amount / zero address) revert", async () => {
        const { token } = await deploy();
        await expect(token.transfer(ethers.ZeroAddress, 1)).to.be.reverted;
    });
});
