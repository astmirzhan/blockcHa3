import { expect } from "chai";
import { ethers } from "hardhat";
import { loadFixture } from "@nomicfoundation/hardhat-toolbox/network-helpers";
import { MyToken } from "../typechain-types";
import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";

describe("MyToken (ERC-20)", function () {
    // Fixture for deploying the contract
    async function deployTokenFixture() {
        const [owner, addr1, addr2] = await ethers.getSigners();

        const tokenName = "My Token";
        const tokenSymbol = "MTK";
        const tokenDecimals = 18;
        const initialSupply = 1000000n; // 1 million tokens

        const MyToken = await ethers.getContractFactory("MyToken");
        const myToken = await MyToken.deploy(
            tokenName,
            tokenSymbol,
            tokenDecimals,
            initialSupply
        );

        const totalSupply = initialSupply * 10n ** BigInt(tokenDecimals);

        return { myToken, owner, addr1, addr2, tokenName, tokenSymbol, tokenDecimals, initialSupply, totalSupply };
    }

    describe("Deployment", function () {
        it("Should set the right name and symbol", async function () {
            const { myToken, tokenName, tokenSymbol } = await loadFixture(deployTokenFixture);

            expect(await myToken.name()).to.equal(tokenName);
            expect(await myToken.symbol()).to.equal(tokenSymbol);
        });

        it("Should set the right decimals", async function () {
            const { myToken, tokenDecimals } = await loadFixture(deployTokenFixture);

            expect(await myToken.decimals()).to.equal(tokenDecimals);
        });

        it("Should assign the total supply to the owner", async function () {
            const { myToken, owner, totalSupply } = await loadFixture(deployTokenFixture);

            expect(await myToken.balanceOf(owner.address)).to.equal(totalSupply);
        });

        it("Should set the right owner", async function () {
            const { myToken, owner } = await loadFixture(deployTokenFixture);

            expect(await myToken.owner()).to.equal(owner.address);
        });
    });

    describe("Transfers", function () {
        it("Should transfer tokens between accounts", async function () {
            const { myToken, owner, addr1, addr2 } = await loadFixture(deployTokenFixture);

            const transferAmount = ethers.parseEther("100");

            // Transfer from owner to addr1
            await expect(myToken.transfer(addr1.address, transferAmount))
                .to.emit(myToken, "Transfer")
                .withArgs(owner.address, addr1.address, transferAmount);

            expect(await myToken.balanceOf(addr1.address)).to.equal(transferAmount);

            // Transfer from addr1 to addr2
            await expect(myToken.connect(addr1).transfer(addr2.address, transferAmount))
                .to.emit(myToken, "Transfer")
                .withArgs(addr1.address, addr2.address, transferAmount);

            expect(await myToken.balanceOf(addr2.address)).to.equal(transferAmount);
            expect(await myToken.balanceOf(addr1.address)).to.equal(0);
        });

        it("Should fail if sender doesn't have enough tokens", async function () {
            const { myToken, owner, addr1 } = await loadFixture(deployTokenFixture);

            const initialOwnerBalance = await myToken.balanceOf(owner.address);

            await expect(
                myToken.connect(addr1).transfer(owner.address, 1n)
            ).to.be.revertedWithCustomError(myToken, "ERC20InsufficientBalance");

            expect(await myToken.balanceOf(owner.address)).to.equal(initialOwnerBalance);
        });
    });

    describe("Allowances", function () {
        it("Should approve and transferFrom correctly", async function () {
            const { myToken, owner, addr1 } = await loadFixture(deployTokenFixture);

            const approveAmount = ethers.parseEther("500");

            await expect(myToken.approve(addr1.address, approveAmount))
                .to.emit(myToken, "Approval")
                .withArgs(owner.address, addr1.address, approveAmount);

            expect(await myToken.allowance(owner.address, addr1.address)).to.equal(approveAmount);

            await myToken.connect(addr1).transferFrom(owner.address, addr1.address, approveAmount);

            expect(await myToken.balanceOf(addr1.address)).to.equal(approveAmount);
            expect(await myToken.allowance(owner.address, addr1.address)).to.equal(0);
        });

        it("Should fail transferFrom without allowance", async function () {
            const { myToken, owner, addr1 } = await loadFixture(deployTokenFixture);

            await expect(
                myToken.connect(addr1).transferFrom(owner.address, addr1.address, 1n)
            ).to.be.revertedWithCustomError(myToken, "ERC20InsufficientAllowance");
        });
    });

    describe("Minting", function () {
        it("Should allow owner to mint tokens", async function () {
            const { myToken, owner, addr1 } = await loadFixture(deployTokenFixture);

            const mintAmount = ethers.parseEther("1000");

            await expect(myToken.mint(addr1.address, mintAmount))
                .to.emit(myToken, "Transfer")
                .withArgs(ethers.ZeroAddress, addr1.address, mintAmount);

            expect(await myToken.balanceOf(addr1.address)).to.equal(mintAmount);
        });

        it("Should fail if non-owner tries to mint", async function () {
            const { myToken, addr1 } = await loadFixture(deployTokenFixture);

            await expect(
                myToken.connect(addr1).mint(addr1.address, 1000n)
            ).to.be.revertedWithCustomError(myToken, "OwnableUnauthorizedAccount");
        });
    });

    describe("Burning", function () {
        it("Should allow users to burn their tokens", async function () {
            const { myToken, owner, totalSupply } = await loadFixture(deployTokenFixture);

            const burnAmount = ethers.parseEther("1000");

            await expect(myToken.burn(burnAmount))
                .to.emit(myToken, "Transfer")
                .withArgs(owner.address, ethers.ZeroAddress, burnAmount);

            expect(await myToken.balanceOf(owner.address)).to.equal(totalSupply - burnAmount);
        });

        it("Should fail if burning more than balance", async function () {
            const { myToken, addr1 } = await loadFixture(deployTokenFixture);

            await expect(
                myToken.connect(addr1).burn(1n)
            ).to.be.revertedWithCustomError(myToken, "ERC20InsufficientBalance");
        });
    });

    describe("Batch Transfer", function () {
        it("Should batch transfer to multiple addresses", async function () {
            const { myToken, owner, addr1, addr2 } = await loadFixture(deployTokenFixture);

            const amount1 = ethers.parseEther("100");
            const amount2 = ethers.parseEther("200");

            await myToken.batchTransfer(
                [addr1.address, addr2.address],
                [amount1, amount2]
            );

            expect(await myToken.balanceOf(addr1.address)).to.equal(amount1);
            expect(await myToken.balanceOf(addr2.address)).to.equal(amount2);
        });

        it("Should fail if arrays length mismatch", async function () {
            const { myToken, addr1, addr2 } = await loadFixture(deployTokenFixture);

            const amount1 = ethers.parseEther("100");

            await expect(
                myToken.batchTransfer([addr1.address, addr2.address], [amount1])
            ).to.be.revertedWith("Arrays length mismatch");
        });
    });
});
