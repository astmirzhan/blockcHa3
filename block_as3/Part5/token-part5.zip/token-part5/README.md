# Part 4 — Professional Hardhat Development Environment

Полнофункциональная профессиональная среда разработки смарт-контрактов с Hardhat, включающая ERC-20 и ERC-721 контракты, тесты, скрипты деплоя и отчётность по газу.

## 📋 Содержание

- [Установка](#установка)
- [Структура проекта](#структура-проекта)
- [Команды](#команды)
- [Смарт-контракты](#смарт-контракты)
- [Тестирование](#тестирование)
- [Hardhat Console](#hardhat-console)
- [Деплой](#деплой)
- [Конфигурация](#конфигурация)

## 🚀 Установка

```bash
# Установка зависимостей
npm install

# Копирование файла окружения
cp .env.example .env

# Редактирование .env с вашими ключами (опционально, для testnet)
```

## 📁 Структура проекта

```
Part4/
├── contracts/
│   ├── MyToken.sol      # ERC-20 токен
│   └── MyNFT.sol        # ERC-721 NFT
├── scripts/
│   ├── deploy-token.ts  # Скрипт деплоя ERC-20
│   └── deploy-nft.ts    # Скрипт деплоя ERC-721
├── test/
│   ├── MyToken.test.ts  # Тесты ERC-20
│   └── MyNFT.test.ts    # Тесты ERC-721
├── docs/
│   └── ERC_STANDARDS_ANALYSIS.md  # Анализ ERC стандартов
├── hardhat.config.ts    # Конфигурация Hardhat
├── .env.example         # Пример переменных окружения
└── package.json
```

## ⚡ Команды

### Компиляция

```bash
# Компиляция контрактов
npm run compile
# или
npx hardhat compile
```

### Тестирование

```bash
# Запуск тестов
npm run test
# или
npx hardhat test

# Запуск тестов с отчётом по газу
npm run test:gas
# или
REPORT_GAS=true npx hardhat test

# Покрытие кода тестами
npm run coverage
# или
npx hardhat coverage
```

### Локальная сеть

```bash
# Запуск локальной ноды Hardhat
npm run node
# или
npx hardhat node
```

### Деплой

```bash
# Деплой токена на локальную сеть
npm run deploy:token:local

# Деплой NFT на локальную сеть
npm run deploy:nft:local

# Деплой на Sepolia (требуется .env)
npm run deploy:token -- --network sepolia
npm run deploy:nft -- --network sepolia
```

## 📜 Смарт-контракты

### MyToken (ERC-20)

Полнофункциональный ERC-20 токен с возможностями:

- **Minting** — минтинг новых токенов (только owner)
- **Burning** — сжигание токенов
- **Batch Transfer** — массовая отправка токенов
- **Ownable** — контроль доступа

### MyNFT (ERC-721)

Полнофункциональная NFT коллекция с возможностями:

- **Minting** — публичный минтинг с оплатой
- **Owner Minting** — бесплатный минтинг владельцем
- **URI Storage** — хранение метаданных
- **Enumerable** — перечисление токенов
- **Minting Controls** — управление минтингом
- **Withdrawal** — вывод средств

## 🧪 Тестирование

Проект включает полный набор тестов с использованием Mocha/Chai:

```bash
# Запуск всех тестов
npx hardhat test

# Запуск конкретного теста
npx hardhat test test/MyToken.test.ts
npx hardhat test test/MyNFT.test.ts

# Подробный вывод
npx hardhat test --verbose
```

### Отчёт по газу

```bash
REPORT_GAS=true npx hardhat test
```

Результат сохраняется в `gas-report.txt`.

## 💻 Hardhat Console

Hardhat Console — интерактивная консоль для взаимодействия с контрактами:

```bash
# Запуск консоли на локальной сети
npm run console:local
# или
npx hardhat console --network localhost
```

### Примеры использования консоли

```javascript
// Получение аккаунтов
const [owner, addr1] = await ethers.getSigners();

// Деплой токена
const MyToken = await ethers.getContractFactory("MyToken");
const token = await MyToken.deploy("My Token", "MTK", 18, 1000000);
await token.waitForDeployment();

// Проверка баланса
const balance = await token.balanceOf(owner.address);
console.log("Balance:", ethers.formatEther(balance));

// Трансфер токенов
await token.transfer(addr1.address, ethers.parseEther("100"));

// Минтинг токенов
await token.mint(addr1.address, ethers.parseEther("500"));

// ========== NFT ==========

// Деплой NFT
const MyNFT = await ethers.getContractFactory("MyNFT");
const nft = await MyNFT.deploy(
  "My NFT", 
  "MNFT", 
  "https://api.example.com/", 
  10000, 
  ethers.parseEther("0.01")
);
await nft.waitForDeployment();

// Минтинг NFT
await nft.mint("token1.json", { value: ethers.parseEther("0.01") });

// Проверка владельца токена
const owner0 = await nft.ownerOf(0);
console.log("Token 0 owner:", owner0);

// Получение URI
const uri = await nft.tokenURI(0);
console.log("Token URI:", uri);

// Получение всех токенов пользователя
const tokens = await nft.tokensOfOwner(owner.address);
console.log("User tokens:", tokens);
```

## ⚙️ Конфигурация

### Переменные окружения (.env)

```env
# RPC URL для Sepolia
SEPOLIA_RPC_URL=https://eth-sepolia.g.alchemy.com/v2/YOUR_KEY

# Приватный ключ для деплоя
PRIVATE_KEY=your_private_key

# API ключ Etherscan для верификации
ETHERSCAN_API_KEY=your_etherscan_key

# API ключ CoinMarketCap для отчёта по газу в USD
COINMARKETCAP_API_KEY=your_cmc_key

# Включить отчёт по газу
REPORT_GAS=true
```

### Сети

| Сеть | Chain ID | Описание |
|------|----------|----------|
| hardhat | 31337 | Встроенная тестовая сеть |
| localhost | 31337 | Локальная нода Hardhat |
| sepolia | 11155111 | Ethereum тестнет |

## 📊 Gas Reporter

Проект включает плагин `hardhat-gas-reporter` для анализа потребления газа:

```bash
REPORT_GAS=true npx hardhat test
```

Отчёт показывает:
- Газ для каждого метода контракта
- Минимальный/максимальный/средний газ
- Стоимость в USD (с API ключом CoinMarketCap)

## 🔐 Безопасность

- Используются проверенные контракты OpenZeppelin
- Контроль доступа через Ownable
- Проверка на reentrancy в функциях вывода
- Валидация входных данных

## 📚 Дополнительная документация

- [ERC Standards Analysis](./docs/ERC_STANDARDS_ANALYSIS.md) — подробный анализ ERC-20 и ERC-721 стандартов
