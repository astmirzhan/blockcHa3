import { expect } from "chai";
import { ethers } from "hardhat";
import { loadFixture } from "@nomicfoundation/hardhat-toolbox/network-helpers";
import { MyNFT } from "../typechain-types";

describe("MyNFT (ERC-721)", function () {
    // Fixture for deploying the contract
    async function deployNFTFixture() {
        const [owner, addr1, addr2] = await ethers.getSigners();

        const nftName = "My NFT Collection";
        const nftSymbol = "MNFT";
        const baseURI = "https://api.example.com/metadata/";
        const maxSupply = 10000n;
        const mintPrice = ethers.parseEther("0.01");

        const MyNFT = await ethers.getContractFactory("MyNFT");
        const myNFT = await MyNFT.deploy(
            nftName,
            nftSymbol,
            baseURI,
            maxSupply,
            mintPrice
        );

        return { myNFT, owner, addr1, addr2, nftName, nftSymbol, baseURI, maxSupply, mintPrice };
    }

    describe("Deployment", function () {
        it("Should set the right name and symbol", async function () {
            const { myNFT, nftName, nftSymbol } = await loadFixture(deployNFTFixture);

            expect(await myNFT.name()).to.equal(nftName);
            expect(await myNFT.symbol()).to.equal(nftSymbol);
        });

        it("Should set the right owner", async function () {
            const { myNFT, owner } = await loadFixture(deployNFTFixture);

            expect(await myNFT.owner()).to.equal(owner.address);
        });

        it("Should set the right max supply and mint price", async function () {
            const { myNFT, maxSupply, mintPrice } = await loadFixture(deployNFTFixture);

            expect(await myNFT.maxSupply()).to.equal(maxSupply);
            expect(await myNFT.mintPrice()).to.equal(mintPrice);
        });

        it("Should enable minting by default", async function () {
            const { myNFT } = await loadFixture(deployNFTFixture);

            expect(await myNFT.mintingEnabled()).to.be.true;
        });
    });

    describe("Minting", function () {
        it("Should mint an NFT with correct payment", async function () {
            const { myNFT, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            const tokenURI = "token1.json";

            await expect(myNFT.connect(addr1).mint(tokenURI, { value: mintPrice }))
                .to.emit(myNFT, "NFTMinted")
                .withArgs(addr1.address, 0, tokenURI);

            expect(await myNFT.ownerOf(0)).to.equal(addr1.address);
            expect(await myNFT.balanceOf(addr1.address)).to.equal(1);
        });

        it("Should fail with insufficient payment", async function () {
            const { myNFT, addr1 } = await loadFixture(deployNFTFixture);

            await expect(
                myNFT.connect(addr1).mint("token.json", { value: ethers.parseEther("0.005") })
            ).to.be.revertedWith("Insufficient payment");
        });

        it("Should allow owner to mint for free", async function () {
            const { myNFT, owner, addr1 } = await loadFixture(deployNFTFixture);

            const tokenURI = "free-token.json";

            await expect(myNFT.ownerMint(addr1.address, tokenURI))
                .to.emit(myNFT, "NFTMinted")
                .withArgs(addr1.address, 0, tokenURI);

            expect(await myNFT.ownerOf(0)).to.equal(addr1.address);
        });

        it("Should fail owner mint if not owner", async function () {
            const { myNFT, addr1, addr2 } = await loadFixture(deployNFTFixture);

            await expect(
                myNFT.connect(addr1).ownerMint(addr2.address, "token.json")
            ).to.be.revertedWithCustomError(myNFT, "OwnableUnauthorizedAccount");
        });

        it("Should increment token IDs correctly", async function () {
            const { myNFT, owner, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token0.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token1.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token2.json", { value: mintPrice });

            expect(await myNFT.ownerOf(0)).to.equal(addr1.address);
            expect(await myNFT.ownerOf(1)).to.equal(addr1.address);
            expect(await myNFT.ownerOf(2)).to.equal(addr1.address);
            expect(await myNFT.balanceOf(addr1.address)).to.equal(3);
        });
    });

    describe("Minting Controls", function () {
        it("Should toggle minting on/off", async function () {
            const { myNFT, owner, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            await expect(myNFT.toggleMinting())
                .to.emit(myNFT, "MintingToggled")
                .withArgs(false);

            expect(await myNFT.mintingEnabled()).to.be.false;

            await expect(
                myNFT.connect(addr1).mint("token.json", { value: mintPrice })
            ).to.be.revertedWith("Minting is disabled");

            await myNFT.toggleMinting();
            expect(await myNFT.mintingEnabled()).to.be.true;
        });

        it("Should update mint price", async function () {
            const { myNFT, owner } = await loadFixture(deployNFTFixture);

            const newPrice = ethers.parseEther("0.05");
            await myNFT.setMintPrice(newPrice);

            expect(await myNFT.mintPrice()).to.equal(newPrice);
        });

        it("Should update base URI", async function () {
            const { myNFT, owner } = await loadFixture(deployNFTFixture);

            const newBaseURI = "https://new-api.example.com/";

            await expect(myNFT.setBaseURI(newBaseURI))
                .to.emit(myNFT, "BaseURIUpdated")
                .withArgs(newBaseURI);
        });
    });

    describe("Transfers", function () {
        it("Should transfer NFT between accounts", async function () {
            const { myNFT, owner, addr1, addr2, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token.json", { value: mintPrice });

            await expect(myNFT.connect(addr1).transferFrom(addr1.address, addr2.address, 0))
                .to.emit(myNFT, "Transfer")
                .withArgs(addr1.address, addr2.address, 0);

            expect(await myNFT.ownerOf(0)).to.equal(addr2.address);
        });

        it("Should fail transfer if not owner or approved", async function () {
            const { myNFT, addr1, addr2, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token.json", { value: mintPrice });

            await expect(
                myNFT.connect(addr2).transferFrom(addr1.address, addr2.address, 0)
            ).to.be.revertedWithCustomError(myNFT, "ERC721InsufficientApproval");
        });
    });

    describe("Approvals", function () {
        it("Should approve and transferFrom correctly", async function () {
            const { myNFT, addr1, addr2, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token.json", { value: mintPrice });

            await myNFT.connect(addr1).approve(addr2.address, 0);
            expect(await myNFT.getApproved(0)).to.equal(addr2.address);

            await myNFT.connect(addr2).transferFrom(addr1.address, addr2.address, 0);
            expect(await myNFT.ownerOf(0)).to.equal(addr2.address);
        });

        it("Should set approval for all", async function () {
            const { myNFT, addr1, addr2, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token0.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token1.json", { value: mintPrice });

            await myNFT.connect(addr1).setApprovalForAll(addr2.address, true);
            expect(await myNFT.isApprovedForAll(addr1.address, addr2.address)).to.be.true;

            // addr2 can now transfer any of addr1's tokens
            await myNFT.connect(addr2).transferFrom(addr1.address, addr2.address, 0);
            await myNFT.connect(addr2).transferFrom(addr1.address, addr2.address, 1);

            expect(await myNFT.balanceOf(addr2.address)).to.equal(2);
        });
    });

    describe("Token URI", function () {
        it("Should return correct token URI", async function () {
            const { myNFT, addr1, baseURI, mintPrice } = await loadFixture(deployNFTFixture);

            const tokenURI = "unique-token.json";
            await myNFT.connect(addr1).mint(tokenURI, { value: mintPrice });

            expect(await myNFT.tokenURI(0)).to.equal(baseURI + tokenURI);
        });
    });

    describe("Enumeration", function () {
        it("Should return tokens of owner", async function () {
            const { myNFT, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token0.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token1.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token2.json", { value: mintPrice });

            const tokens = await myNFT.tokensOfOwner(addr1.address);

            expect(tokens.length).to.equal(3);
            expect(tokens[0]).to.equal(0n);
            expect(tokens[1]).to.equal(1n);
            expect(tokens[2]).to.equal(2n);
        });

        it("Should return total supply", async function () {
            const { myNFT, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token0.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token1.json", { value: mintPrice });

            expect(await myNFT.totalSupply()).to.equal(2);
        });
    });

    describe("Withdrawals", function () {
        it("Should allow owner to withdraw contract balance", async function () {
            const { myNFT, owner, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            // Mint some NFTs to add ETH to contract
            await myNFT.connect(addr1).mint("token0.json", { value: mintPrice });
            await myNFT.connect(addr1).mint("token1.json", { value: mintPrice });

            const contractBalance = await ethers.provider.getBalance(await myNFT.getAddress());
            expect(contractBalance).to.equal(mintPrice * 2n);

            const ownerBalanceBefore = await ethers.provider.getBalance(owner.address);

            const tx = await myNFT.withdraw();
            const receipt = await tx.wait();
            const gasUsed = receipt!.gasUsed * receipt!.gasPrice;

            const ownerBalanceAfter = await ethers.provider.getBalance(owner.address);

            expect(ownerBalanceAfter).to.equal(ownerBalanceBefore + contractBalance - gasUsed);
        });

        it("Should fail withdrawal if not owner", async function () {
            const { myNFT, addr1, mintPrice } = await loadFixture(deployNFTFixture);

            await myNFT.connect(addr1).mint("token.json", { value: mintPrice });

            await expect(
                myNFT.connect(addr1).withdraw()
            ).to.be.revertedWithCustomError(myNFT, "OwnableUnauthorizedAccount");
        });

        it("Should fail withdrawal if no balance", async function () {
            const { myNFT, owner } = await loadFixture(deployNFTFixture);

            await expect(myNFT.withdraw()).to.be.revertedWith("No balance to withdraw");
        });
    });

    describe("Interface Support", function () {
        it("Should support ERC-721 interface", async function () {
            const { myNFT } = await loadFixture(deployNFTFixture);

            // ERC-721 interface ID: 0x80ac58cd
            expect(await myNFT.supportsInterface("0x80ac58cd")).to.be.true;
        });

        it("Should support ERC-721 Metadata interface", async function () {
            const { myNFT } = await loadFixture(deployNFTFixture);

            // ERC-721 Metadata interface ID: 0x5b5e139f
            expect(await myNFT.supportsInterface("0x5b5e139f")).to.be.true;
        });

        it("Should support ERC-721 Enumerable interface", async function () {
            const { myNFT } = await loadFixture(deployNFTFixture);

            // ERC-721 Enumerable interface ID: 0x780e9d63
            expect(await myNFT.supportsInterface("0x780e9d63")).to.be.true;
        });
    });
});
