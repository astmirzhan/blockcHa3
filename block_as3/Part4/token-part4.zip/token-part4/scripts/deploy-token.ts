import { ethers } from "hardhat";

async function main() {
    console.log("🚀 Deploying MyToken (ERC-20)...\n");

    const [deployer] = await ethers.getSigners();
    console.log("📍 Deployer address:", deployer.address);
    console.log("💰 Deployer balance:", ethers.formatEther(await ethers.provider.getBalance(deployer.address)), "ETH\n");

    // Token parameters
    const tokenName = "My Token";
    const tokenSymbol = "MTK";
    const tokenDecimals = 18;
    const initialSupply = 1000000; // 1 million tokens

    console.log("📝 Token Parameters:");
    console.log("   Name:", tokenName);
    console.log("   Symbol:", tokenSymbol);
    console.log("   Decimals:", tokenDecimals);
    console.log("   Initial Supply:", initialSupply.toLocaleString(), "tokens\n");

    // Deploy contract
    const MyToken = await ethers.getContractFactory("MyToken");
    const myToken = await MyToken.deploy(
        tokenName,
        tokenSymbol,
        tokenDecimals,
        initialSupply
    );

    await myToken.waitForDeployment();
    const tokenAddress = await myToken.getAddress();

    console.log("✅ MyToken deployed successfully!");
    console.log("📍 Contract address:", tokenAddress);
    console.log("🔗 Total supply:", ethers.formatUnits(await myToken.totalSupply(), tokenDecimals), tokenSymbol);

    // Verify deployment
    const ownerBalance = await myToken.balanceOf(deployer.address);
    console.log("💰 Owner balance:", ethers.formatUnits(ownerBalance, tokenDecimals), tokenSymbol);

    console.log("\n📋 Deployment Summary:");
    console.log("================================");
    console.log(`Contract: ${tokenAddress}`);
    console.log(`Owner: ${deployer.address}`);
    console.log(`Network: ${(await ethers.provider.getNetwork()).name}`);
    console.log("================================\n");

    return myToken;
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("❌ Deployment failed:", error);
        process.exit(1);
    });
